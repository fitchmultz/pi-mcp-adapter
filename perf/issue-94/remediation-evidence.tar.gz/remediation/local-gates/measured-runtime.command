sha256sum -c /workspace/evidence/remediation/fork-matched/candidate-files.sha256 
