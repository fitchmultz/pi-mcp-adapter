node scripts/check-consumer-types.mjs /workspace/remediation-type-consumer/node_modules/@fitchmultz/pi-mcp-adapter 
