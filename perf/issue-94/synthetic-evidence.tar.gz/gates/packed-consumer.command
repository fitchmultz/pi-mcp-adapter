node scripts/compat-package-smoke.mjs
