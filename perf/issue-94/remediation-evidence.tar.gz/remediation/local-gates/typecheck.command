npm run typecheck 
