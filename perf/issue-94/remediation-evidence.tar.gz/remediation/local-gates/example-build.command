npm run --prefix examples/interactive-visualizer build 
