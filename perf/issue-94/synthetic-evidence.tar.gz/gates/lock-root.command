npm exec --yes --package=lockfile-lint@5.0.1 -- lockfile-lint --type npm --allowed-hosts npm --validate-https --path package-lock.json
