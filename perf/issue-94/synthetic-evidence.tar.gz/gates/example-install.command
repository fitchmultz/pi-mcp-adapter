npm ci --prefix examples/interactive-visualizer --ignore-scripts --no-audit --no-fund
