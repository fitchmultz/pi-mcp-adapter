env CONFORMANCE_RESULTS_DIR=/workspace/evidence/remediation/local-gates/conformance-results npm run test:conformance 
