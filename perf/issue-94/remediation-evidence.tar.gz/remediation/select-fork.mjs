import { prepareHost, selectDevelopmentHost } from '/workspace/automation/scripts/hosts.mjs';
import { readFileSync, writeFileSync, copyFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import assert from 'node:assert/strict';
const dir = '/workspace/evidence/remediation/fork-host';
mkdirSync(dir, { recursive: true });
const sha256 = path => createHash('sha256').update(readFileSync(path)).digest('hex');
const host = await prepareHost('/workspace/fork-benchmark-host', 'fork', '/workspace/fork-package', process.env);
assert.equal(host.provenance.ref, 'c17adbc400319887c5ab34fce1ed2a59be746da4');
const selected = selectDevelopmentHost('/workspace/pi-mcp-adapter', host, process.env);
const hostLock = '/workspace/fork-benchmark-host/package-lock.json';
const selectedInstalledLock = '/workspace/pi-mcp-adapter/node_modules/.package-lock.json';
copyFileSync(hostLock, dir + '/package-lock.json');
copyFileSync(selectedInstalledLock, dir + '/selected-installed-lock.json');
copyFileSync('/workspace/fork-package/receipt.json', dir + '/fork-receipt.json');
copyFileSync('/workspace/fork-package/manifest.json', dir + '/fork-manifest.json');
const identity = { observedAt: new Date().toISOString(), forkMain: host.provenance.ref, host, selected,
  hostLock: { path: hostLock, sha256: sha256(hostLock) },
  selectedInstalledLock: { path: selectedInstalledLock, sha256: sha256(selectedInstalledLock) },
  artifacts: host.provenance.packages.map(pkg => ({ ...pkg, path: resolve('/workspace/fork-package', pkg.file) })) };
writeFileSync(dir + '/identity.json', JSON.stringify(identity, null, 2));
console.log(JSON.stringify(identity, null, 2));
