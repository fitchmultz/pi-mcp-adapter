npm run typecheck
