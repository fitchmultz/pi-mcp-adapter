#!/usr/bin/env bash
set -eu
export PATH=/workspace/toolchain/node_modules/.bin:$PATH
cd /workspace/pi-mcp-adapter
out=/workspace/evidence/remediation/local-gates
mkdir -p "$out"
printf 'gate\texit\n' > "$out/exits.tsv"
run() {
  name=$1; shift
  printf '%q ' "$@" > "$out/$name.command"; printf '\n' >> "$out/$name.command"
  set +e; "$@" > "$out/$name.log" 2>&1; code=$?; set -e
  printf '%s\t%s\n' "$name" "$code" >> "$out/exits.tsv"
  if [ "$code" -ne 0 ]; then tail -90 "$out/$name.log"; exit "$code"; fi
}
run example-build npm run --prefix examples/interactive-visualizer build
run build npm run build
run typecheck npm run typecheck
run full-tests env PI_COMPAT_EVIDENCE_DIR="$out/retained-journals" npm test
run conformance env CONFORMANCE_RESULTS_DIR="$out/conformance-results" npm run test:conformance
run lock-root npm exec --yes --package=lockfile-lint@5.0.1 -- lockfile-lint --type npm --allowed-hosts npm --validate-https --path package-lock.json
run lock-example npm exec --yes --package=lockfile-lint@5.0.1 -- lockfile-lint --type npm --allowed-hosts npm --validate-https --path examples/interactive-visualizer/package-lock.json
consumer=/workspace/remediation-type-consumer
mkdir -p "$consumer"
printf '{"private":true,"dependencies":{"@fitchmultz/pi-mcp-adapter":"file:/workspace/evidence/remediation/qualification/fork/fitchmultz-pi-mcp-adapter-8.0.1.tgz"}}\n' > "$consumer/package.json"
(cd "$consumer" && npm install --ignore-scripts --omit=dev --no-audit --no-fund) > "$out/type-consumer-install.log" 2>&1
run consumer-types node scripts/check-consumer-types.mjs "$consumer/node_modules/@fitchmultz/pi-mcp-adapter"
run whitespace git diff --check
run measured-runtime sha256sum -c /workspace/evidence/remediation/fork-matched/candidate-files.sha256
cat "$out/exits.tsv"
