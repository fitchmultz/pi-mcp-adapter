#!/usr/bin/env bash
set -eu
export PATH=/workspace/toolchain/node_modules/.bin:$PATH
out=/workspace/evidence/remediation/fork-matched
mkdir -p "$out"
cd /workspace/baseline
npm run build > "$out/baseline-build.log" 2>&1
cd /workspace/pi-mcp-adapter
npm run build > "$out/candidate-build.log" 2>&1
sha256sum metadata-cache.ts tool-loader.ts init.ts dist/metadata-cache.js dist/tool-loader.js dist/init.js > "$out/candidate-files.sha256"
stamp=$(node -e "console.log(JSON.parse(require('fs').readFileSync('/workspace/evidence/matched/A1.json')).fixtureTime)")
printf 'sample\texit\tstarted\tfinished\n' > "$out/exits.tsv"
for n in 1 2 3 4 5; do
  if (( n % 2 )); then sides='A B'; else sides='B A'; fi
  for side in $sides; do
    if [ "$side" = A ]; then source=/workspace/baseline; else source=/workspace/pi-mcp-adapter; fi
    name="$side$n"
    started=$(date -u +%FT%TZ)
    printf 'node scripts/benchmark-session-cache.mjs --source %s --fixtures %s/%s-fixtures --output %s/%s.json --timestamp %s --identity /workspace/evidence/remediation/fork-host/identity.json\n' "$source" "$out" "$name" "$out" "$name" "$stamp" >> "$out/commands.log"
    set +e
    node scripts/benchmark-session-cache.mjs --source "$source" --fixtures "$out/$name-fixtures" --output "$out/$name.json" --timestamp "$stamp" --identity /workspace/evidence/remediation/fork-host/identity.json > "$out/$name.log" 2>&1
    code=$?
    set -e
    printf '%s\t%s\t%s\t%s\n' "$name" "$code" "$started" "$(date -u +%FT%TZ)" >> "$out/exits.tsv"
    if [ "$code" -ne 0 ]; then cat "$out/$name.log"; exit "$code"; fi
  done
done
node perf/issue-94/summarize.mjs "$out" > "$out/summary.json"
node perf/issue-94/summarize.mjs /workspace/evidence/matched > "$out/historical-official-summary.json"
cat "$out/exits.tsv"
cat "$out/summary.json"
