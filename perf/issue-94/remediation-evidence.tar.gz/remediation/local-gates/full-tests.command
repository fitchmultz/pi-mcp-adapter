env PI_COMPAT_EVIDENCE_DIR=/workspace/evidence/remediation/local-gates/retained-journals npm test 
